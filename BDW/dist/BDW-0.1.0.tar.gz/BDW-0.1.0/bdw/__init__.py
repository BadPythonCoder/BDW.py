'''
A bad discord wrapper made by Fox551/BadPythonProgrammer and TBSharedAccount and Nixtrome.

for everybody that wants to steal this for some weird reason, yeah no this is our... thing. Just gonna slap some symbols on it
©©©©©©20212021202120212021 by Fox551 and TBSharedAccount and Nixtxrome!!!! CHECK DATE OF REPL AND GITHUB FOR PROOV D:<
'''
from .Guild import *
from .Bot import *
from .Channel import *
from .Intents import *
from .User import *
from .Embed import *