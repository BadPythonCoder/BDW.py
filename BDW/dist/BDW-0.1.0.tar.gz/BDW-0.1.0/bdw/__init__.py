'''
A bad discord wrapper made by Fox551/BadPythonProgrammer.
'''
# from .comm import *
from .Guild import *
from .Bot import *