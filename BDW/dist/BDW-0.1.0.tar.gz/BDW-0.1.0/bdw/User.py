from .comm import *

class User:
  def __init__(self, raw):
    print(raw)