from .comm import *

class ContextBase:
  def __init__(self, dataraw):
    self.dataraw = dataraw
  def setdata(self, name, data):
    exec(f"self.{name} = {data}")

class Message(ContextBase):
  id = 0
  channel_id = 0
  guild_id = 0
  author = 0
  content = ""
  timestamp = 0
  etimestamp = 0
  tts = False
  attachments = []
  embeds = []
  reactions = []
  pinned = False
  msgtype = 0
  components = []
  stickers = []
  def process(self):
    self.id = self.dataraw["id"]
    self.channel_id = 5827