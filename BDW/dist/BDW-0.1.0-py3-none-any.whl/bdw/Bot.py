from .comm import *
from .Intents import *
import websocket, threading

class Bot:
  def __init__(self, intents=[]):
    self.guilds = []
    self.intents = IG(intents)
  def start(self, auth):
    self.guilds = APIcall("/users/@me/guilds","GET", auth,{})
    # Begin Gateway
    
    # End Gateway 